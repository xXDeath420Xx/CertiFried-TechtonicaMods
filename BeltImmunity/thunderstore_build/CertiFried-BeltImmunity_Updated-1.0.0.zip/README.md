# BeltImmunity Updated

Makes you immune to conveyor belt movement. Walk across belts without being pushed around!

## Features

- Prevents conveyor belts from pushing/pulling the player
- Walk freely across any conveyor system
- No configuration needed - just install and play

## Installation

1. Install with r2modman or manually place in BepInEx/plugins folder
2. That's it! You're now immune to belt movement

## Original Author

This mod was originally created by **Equinox** ([CubeSuite](https://github.com/CubeSuite)).

Original repository: https://github.com/CubeSuite/TTMod-BeltImmunity

## License

This mod is licensed under GPL-3.0, the same license as the original mod.

## Updated By

Updated for current game version by **CertiFried**.
