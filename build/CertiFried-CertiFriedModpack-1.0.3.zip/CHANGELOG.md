# Changelog

## [1.0.3] - 2026-01-07

### Changed
- Updated AmbientLife to 2.0.0 (major overhaul with smart AI, 13 creature types, in-game UI)

## [1.0.2] - 2026-01-07

### Fixed
- Dependency version corrections

## [1.0.0] - 2026-01-07

### Added
- Initial modpack release
- Complete collection of 22 CertiFried mods for Techtonica
- Core Framework: TechtonicaFramework 1.2.0
- Production mods: AdvancedMachines, AtlantumReactor, MorePlanters, PlanterCoreClusters
- Logistics mods: EnhancedLogistics, WormholeChests, DroneLogistics, Recycler
- Exploration mods: AmbientLife, PetsCompanions, HazardousWorld
- Gameplay mods: SurvivalElements, MobilityPlus, NarrativeExpansion, BioProcessing
- QoL mods: BeltImmunity, ChainExplosives, DevTools, OmniseekerPlus, Restock, AtlantumEnrichment
