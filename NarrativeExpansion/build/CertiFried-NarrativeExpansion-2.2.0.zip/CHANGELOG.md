# Changelog

All notable changes to NarrativeExpansion will be documented in this file.

## [2.2.0] - 2026-01-07

### Added
- Real 3D robot models for all NPCs (no more primitive shapes!)
- NPCAssetLoader system for loading robot models from AssetBundles
- Bundles folder with mech_companion, robot_sphere, robot_metallic assets

### Changed
- Wanderer now uses MechPolyart model (Sci-Fi warrior style)
- Engineer now uses RobotMetallic model (humanoid robot)
- Archivist now uses MechPBR model (high-detail warrior)
- Scout now uses RobotSphere model (floating sphere drone)
- Oracle now uses MechWarrior model (hero-style character)
- Each NPC has unique scale for visual variety

## [2.1.0] - 2026-01-07

### Changed
- Major narrative system improvements
- Updated dependency on TechtonicaFramework 1.2.0
- Better integration with dialogue systems

## [1.0.0] - 2025-01-05

### Added
- Initial release
- Extended dialogue system framework
- Quest chain support
- Story content expansion hooks
- Integration with TechtonicaFramework narrative system
